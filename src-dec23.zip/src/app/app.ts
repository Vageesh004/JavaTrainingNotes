import { Component, signal } from '@angular/core';
import { RouterModule, RouterOutlet } from '@angular/router';
import { Addemp } from "./components/addemp/addemp";
import { Emplist } from "./components/emplist/emplist";
import { EmpInfo } from "./component/emp-info/emp-info";
import { Header } from "./components/header/header";
import { Main } from "./components/main/main";
import { Footer } from "./components/footer/footer";


@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Addemp, Emplist, EmpInfo, RouterModule, Header, Main, Footer],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('employee-management-app');
}
