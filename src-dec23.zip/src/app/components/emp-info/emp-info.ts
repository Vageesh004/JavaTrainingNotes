import { Component } from '@angular/core';
import { Employee } from '../../models/employee.model';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-emp-info',
  imports: [CommonModule,RouterModule],
  templateUrl: './emp-info.html',
  styleUrl: './emp-info.css',
})
export class EmpInfo {

  empList:Employee[]=[]
   empid!:number
   emp:Employee|null|undefined=null


  ngOnInit():void{
    this.empList=[new Employee(234,'amit','trainer','amit@gmail.com','9090909900',80000,'CSE'),
      new Employee(235,'narine','trainer','narine@gmail.com','9090907888',80000,'CSE'),
      new Employee(236,'gowtham','trainer','gowtham@gmail.com','9090909999',80000,'CSE')
    ]

    this.findById();
  }

  constructor(private route:ActivatedRoute) {}

  findById():void{
    //const id=this.empid;
    const id = Number(this.route.snapshot.paramMap.get('eid'));

    this.emp=this.empList.find(e=>e.eid===id)
  }





}
