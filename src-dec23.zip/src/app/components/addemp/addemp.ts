import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Employee } from '../../models/employee.model';
import { Empservice } from '../../services/empservice';

@Component({
  selector: 'app-addemp',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './addemp.html',
  styleUrl: './addemp.css',
})
export class Addemp {

  employee = new Employee(0,'','','','',0,'');

  constructor(
    private service: Empservice,
    private router: Router
  ) {}

  onSubmit(empForm: NgForm) {
    if (empForm.invalid) return;

    this.service.save(this.employee).subscribe({
      next: () => {
        alert('Employee added successfully');
        this.router.navigate(['/emp/list']);
      },
      error: (err) => {
        console.error('Save failed', err);
      }
    });
  }
}
