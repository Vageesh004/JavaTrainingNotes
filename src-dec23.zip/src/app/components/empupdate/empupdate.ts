import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Employee } from '../../models/employee.model';
import { Empservice } from '../../services/empservice';

@Component({
  selector: 'app-emp-update',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './empupdate.html',
  styleUrl: './empupdate.css',
})
export class EmpUpdate implements OnInit {

  empForm!: FormGroup;
  empId!: number;

  constructor(
    public route: ActivatedRoute,
    public fb: FormBuilder,
    public service: Empservice,
    public router: Router
  ) {}

  ngOnInit(): void {

    this.empId = Number(this.route.snapshot.paramMap.get('eid'));

    this.empForm = this.fb.group({
      eid: [{ value: 0, disabled: true }],
      ename: ['', [Validators.required, Validators.minLength(3)]],
      desg: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.required, Validators.pattern('[6789][0-9]{9}')]],
      salary: [0, Validators.required],
      dept: ['', Validators.required]
    });

    // 🔥 Load employee from db.json
    this.service.findById(this.empId).subscribe({
      next: (emp) => {
        this.empForm.patchValue(emp);
      },
      error: (err) => {
        console.error('Employee not found', err);
      }
    });
  }

  update(): void {
    if (this.empForm.invalid) return;

    const updateEmp = this.empForm.getRawValue();
    console.log('Updating:', updateEmp);

    this.service.update(this.empId, updateEmp).subscribe({
      next: () => {
        alert('Employee updated successfully');
        this.router.navigate(['/emp/list']);
      },
      error: (err) => {
        console.error('Update failed', err);
      }
    });
  }
}
