import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Employee } from '../../models/employee.model';
import { Empservice } from '../../services/empservice';

@Component({
  selector: 'app-emplist',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './emplist.html',
  styleUrl: './emplist.css',
})
export class Emplist implements OnInit {

  empList = signal<Employee[]>([]);

  constructor(private service: Empservice) {}

  ngOnInit(): void {
    this.service.findAll().subscribe({
      next: (data) => {
        console.log('Employees from db.json:', data);
        this.empList.set(data);
      },
      error: (err) => {
        console.error('Error fetching employees', err);
      }
    });
  }
}
