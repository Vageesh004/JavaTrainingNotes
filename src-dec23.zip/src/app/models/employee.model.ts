export class Employee {
    constructor(
      public eid: number,
      public ename: string,
      public desg: string,
      public email: string,
      public mobile: string,
      public salary: number,
      public dept: string
    ) {}
  }
  