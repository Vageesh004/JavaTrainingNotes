import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ColorEg } from './color-eg';

describe('ColorEg', () => {
  let component: ColorEg;
  let fixture: ComponentFixture<ColorEg>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ColorEg]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ColorEg);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
