import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-color-eg',
  imports: [CommonModule],
  templateUrl: './color-eg.html',
  styleUrl: './color-eg.css',
})
export class ColorEg {

  checkColor=false;
  
  changeBGColor(){
   this.checkColor=!this.checkColor;
   document.body.style.backgroundColor=this.checkColor?"Cyan":"Yellow"
  }
}
