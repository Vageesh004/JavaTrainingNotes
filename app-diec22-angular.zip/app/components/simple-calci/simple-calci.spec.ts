import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SimpleCalci } from './simple-calci';

describe('SimpleCalci', () => {
  let component: SimpleCalci;
  let fixture: ComponentFixture<SimpleCalci>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SimpleCalci]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SimpleCalci);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
