import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, NgModel } from '@angular/forms';

@Component({
  selector: 'app-simple-calci',
  imports: [CommonModule,FormsModule],
  templateUrl: './simple-calci.html',
  styleUrl: './simple-calci.css',
})
export class SimpleCalci {

  num1:number=0
  num2:number=0
  op=''
  res:number=0



  calc(op:string){
    this.op=op

    switch(op){
      case 'Add':
        this.res=this.num1+this.num2;
        break;

      case 'Sub':
        this.res=this.num1+this.num2;
        break;

      case 'Prod':
        this.res=this.num1*this.num2;
        break;

      case 'Div':
        this.res=this.num1/this.num2;
        break;

      
    }

  }
  
}
