import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  imports: [CommonModule,FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {
  uname=''
  pwd=''
  msg=""
  status=''

  login(){
    if(this.uname==='admin' && this.pwd==='admin123'){
      this.msg="login successful"
      this.status='success'
    }

    else{
      this.msg="invalid credentials"
      this.status="failed"
    }
  }

}
