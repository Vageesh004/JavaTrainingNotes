import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-ngswitch',
  imports: [CommonModule],
  templateUrl: './ngswitch.html',
  styleUrl: './ngswitch.css',
})
export class Ngswitch {

  choice="home"
  setChoice(choice:string){
    this.choice=choice
  }

}
