import { Component } from '@angular/core';
import { OnclickBoldDirective } from "../../directives/onclick-bold-directive";

@Component({
  selector: 'app-demo',
  imports: [OnclickBoldDirective],
  templateUrl: './demo.html',
  styleUrl: './demo.css',
})
export class Demo {

}
