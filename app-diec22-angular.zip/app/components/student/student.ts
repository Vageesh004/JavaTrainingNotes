import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-student',
  imports: [CommonModule],
  templateUrl: './student.html',
  styleUrl: './student.css',
})
export class Student {

  stud=[{sid:123,sname:'preethi',marks:80},
    {sid:789,sname:'aaaa',marks:80},
    {sid:123,sname:'bbbb',marks:70},
    {sid:123,sname:'cccc',marks:60},
    {sid:123,sname:'dddd',marks:50},
  ]


}
