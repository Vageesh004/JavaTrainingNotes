import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-ngfor',
  imports: [CommonModule],
  templateUrl: './ngfor.html',
  styleUrl: './ngfor.css',
})
export class Ngfor {

  items=[
    {id:1,name:'laptop',cost:70000},
    {id:2,name:'mouse',cost:700},
    {id:3,name:'airpods',cost:6000},
    {id:4,name:'bag',cost:700},
    {id:5,name:'battery',cost:300},

  ]

}
