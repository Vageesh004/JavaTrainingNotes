import { OnclickBoldDirective } from './onclick-bold-directive';

describe('OnclickBoldDirective', () => {
  it('should create an instance', () => {
    const directive = new OnclickBoldDirective();
    expect(directive).toBeTruthy();
  });
});
