import { Component, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css',

})
export class Login {
  @Input() appName=""

  uname!:string;
  pwd!:string

  login=()=>{
    this.notify.emit('Notification emitted from Login');
    alert("-------");
    console.log(this.uname)
    console.log(this.pwd)
  }
  notify: any;

}
