import { Component } from '@angular/core';

@Component({
  selector: 'app-components',
  imports: [],
  templateUrl: './components.html',
  styleUrl: './components.css',
})
export class Components {

}
