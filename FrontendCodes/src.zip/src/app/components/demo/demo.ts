import { Component } from '@angular/core';

@Component({
  selector: 'app-demo',
  imports: [],
  templateUrl: './demo.html',
  styleUrl: './demo.css',
})
export class Demo {
  imgUrl: string ='https://tse3.mm.bing.net/th/id/OIP.e4ArqjfIZRNFUc-tNO358AHaLH?cb=ucfimg2&ucfimg=1&rs=1&pid=ImgDetMain&o=7&rm=3';

  isDisabled: boolean = true;

  color: string = 'blue';
  

}
