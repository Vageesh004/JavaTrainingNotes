import { Component, Input, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import {Hello} from './components/hello/hello';
import { Demo } from "./component/demo/demo";
import { Header } from "./components/header/header";
import { Footer } from "./components/footer/footer";
import { Login } from "./components/login/login";


@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Hello, Demo, Header, Footer, Login],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('my-app');

  @Input() appName="Login Application"
  msg:string=''
notify: any;

  receive(msg:string){
    this.msg=msg
  }
}
